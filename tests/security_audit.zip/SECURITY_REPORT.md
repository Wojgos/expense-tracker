# Raport Bezpieczeństwa - Expense Tracker

**Data:** 2026-04-23  
**Narzędzia:** Bandit 1.9.4, pip-audit 2.10.0, npm audit, CycloneDX SBOM, analiza manualna kodu  
**Zakres:** Backend (Python/FastAPI), Frontend (React/Vite), Docker, infrastruktura

---

## 1. Podsumowanie

| Kategoria                  | Krytyczne | Wysokie | Średnie | Niskie | Razem |
|----------------------------|-----------|---------|---------|--------|-------|
| Statyczna analiza (Bandit) | 0         | 0       | 0       | 1      | 1     |
| Zależności Python (pip-audit)| 0       | 0       | 0       | 0      | 0     |
| Zależności JS (npm audit)  | 0         | 3       | 3       | 0      | 6     |
| Analiza manualna kodu      | 1         | 3       | 3       | 2      | 9     |
| **RAZEM**                  | **1**     | **6**   | **6**   | **3**  | **16**|

---

## 2. Wyniki Bandit (statyczna analiza Python)

**Przeskanowane pliki:** 22 | **LOC:** 1923

### B110 — Try/Except/Pass (LOW / CWE-703)
- **Plik:** `backend/app/services/currency_service.py`, linia 61
- **Opis:** Blok `except Exception: pass` – błędy są po cichu ignorowane, co może ukryć problemy bezpieczeństwa lub awarie.
- **Rekomendacja:** Dodać logowanie błędów zamiast `pass`.

---

## 3. Wyniki pip-audit (zależności Python)

Nie znaleziono znanych podatności w zależnościach Pythona.

> **Uwaga:** Zależności w `requirements.txt` nie mają przypiętych wersji (brak `==x.y.z`), co stanowi ryzyko — przyszłe instalacje mogą pobrać wersje z podatnościami.

---

## 4. Wyniki npm audit (zależności Frontend)

### 4.1. axios 1.0.0–1.14.0 (MODERATE)
- **GHSA-3p68-rc4w-qgx5** — SSRF przez bypass normalizacji NO_PROXY
- **GHSA-fvcv-3m26-pcqx** — Exfiltracja metadanych chmury przez Header Injection
- **Fix:** `npm audit fix` (aktualizacja axios)

### 4.2. vite 7.0.0–7.3.1 (HIGH)
- **GHSA-4w7w-66w2-5vf9** — Path Traversal w obsłudze `.map` zoptymalizowanych deps
- **GHSA-v2wj-q39q-566r** — Bypass `server.fs.deny` za pomocą query strings
- **GHSA-p9ff-h696-f583** — Odczyt dowolnych plików przez WebSocket dev servera
- **Fix:** `npm audit fix` (aktualizacja vite)

### 4.3. flatted ≤3.4.1 (HIGH)
- **GHSA-25h7-pfq9-p65f** — DoS przez nieograniczoną rekursję w `parse()`
- **GHSA-rf6f-7fwh-wjgh** — Prototype Pollution przez `parse()`
- **Fix:** `npm audit fix`

### 4.4. picomatch 4.0.0–4.0.3 (HIGH)
- **GHSA-3v7f-55p6-f55p** — Method Injection w POSIX Character Classes
- **GHSA-c2c7-rcm5-vvqj** — ReDoS przez extglob quantifiers
- **Fix:** `npm audit fix`

### 4.5. brace-expansion <1.1.13 || >=4.0.0 <5.0.5 (MODERATE)
- **GHSA-f886-m6hf-6m8v** — DoS przez zero-step sequence
- **Fix:** `npm audit fix`

### 4.6. follow-redirects ≤1.15.11 (MODERATE)
- **GHSA-r4q5-vmmm-2653** — Wyciek nagłówków autoryzacji przy przekierowaniu cross-domain
- **Fix:** `npm audit fix`

---

## 5. Analiza manualna kodu

### 5.1. [KRYTYCZNA] Hardcoded SECRET_KEY w docker-compose.yml
- **Plik:** `docker-compose.yml`, linia 36
- **Wartość:** `SECRET_KEY: super-secret-dev-key-change-in-prod`
- **Ryzyko:** Atakujący może fałszować tokeny JWT jeśli klucz wycieknie do repozytorium.
- **CWE:** CWE-798 (Use of Hard-coded Credentials)

### 5.2. [WYSOKA] Brak walidacji złożoności hasła
- **Plik:** `backend/app/schemas/user.py`, linia 9
- **Opis:** Pole `password: str` nie wymusza minimalnej długości, złożoności ani obecności cyfr/znaków specjalnych.
- **CWE:** CWE-521 (Weak Password Requirements)

### 5.3. [WYSOKA] Token JWT przechowywany w localStorage
- **Plik:** `frontend/src/contexts/auth_context.tsx`, linia 31, 52
- **Opis:** `localStorage.setItem("token", ...)` — podatne na kradzież tokena przez atak XSS.
- **CWE:** CWE-922 (Insecure Storage of Sensitive Information)
- **Rekomendacja:** Użycie httpOnly cookie zamiast localStorage.

### 5.4. [WYSOKA] WebSocket nie weryfikuje członkostwa w grupie
- **Plik:** `backend/app/api/ws.py`, linia 11–27
- **Opis:** Endpoint WebSocket weryfikuje token JWT, ale nie sprawdza czy użytkownik jest członkiem grupy. Dowolny zalogowany użytkownik może nasłuchiwać powiadomień z dowolnej grupy.
- **CWE:** CWE-862 (Missing Authorization)

### 5.5. [ŚREDNIA] Brak rate limiting na endpointach autoryzacji
- **Plik:** `backend/app/api/auth.py`
- **Opis:** Brak ograniczenia liczby prób logowania i rejestracji — umożliwia brute-force i credential stuffing.
- **CWE:** CWE-307 (Improper Restriction of Excessive Authentication Attempts)

### 5.6. [ŚREDNIA] CORS — wildcard w allow_methods i allow_headers
- **Plik:** `backend/main.py`, linie 44–49
- **Opis:** `allow_methods=["*"], allow_headers=["*"]` — zbyt permisywna konfiguracja CORS.
- **CWE:** CWE-942 (Overly Permissive Cross-domain Whitelist)

### 5.7. [ŚREDNIA] Dockerfile uruchamia aplikację jako root
- **Plik:** `backend/Dockerfile`
- **Opis:** Brak instrukcji `USER` — kontener działa z uprawnieniami root.
- **CWE:** CWE-250 (Execution with Unnecessary Privileges)

### 5.8. [NISKA] Niezapięte wersje zależności Python
- **Plik:** `backend/requirements.txt`
- **Opis:** Brak pinowania wersji (`==x.y.z`) — instalacja może pobrać niesprawdzone wersje.
- **CWE:** CWE-1104 (Use of Unmaintained Third Party Components)

### 5.9. [NISKA] Brak nagłówków bezpieczeństwa w nginx
- **Plik:** `frontend/nginx.conf`
- **Opis:** Brak nagłówków: `X-Content-Type-Options`, `X-Frame-Options`, `Content-Security-Policy`, `Strict-Transport-Security`.
- **CWE:** CWE-693 (Protection Mechanism Failure)

---

## 6. Pliki wygenerowane

| Plik | Opis |
|------|------|
| `SECURITY_REPORT.md` | Ten raport |
| `sbom.json` | Software Bill of Materials (CycloneDX format) |
| `security_report_bandit.json` | Surowe wyniki Bandit (JSON) |
| `security_report_bandit.html` | Raport Bandit (HTML) |
| `security_report_pip_audit.json` | Wyniki pip-audit |
| `npm_audit_report.json` | Wyniki npm audit |
| `VULNERABILITY_FIXES.md` | Opis poprawek 3 wybranych podatności |
